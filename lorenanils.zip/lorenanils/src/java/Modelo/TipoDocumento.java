/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modelo;

public class TipoDocumento {
    private int idTipoDocumento;
    private String Descripcion;

   public static void main(String[] args) {
     
    }
    
}
